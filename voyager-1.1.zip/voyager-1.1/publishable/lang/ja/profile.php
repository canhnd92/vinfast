<?php

return [
    'avatar'           => 'アバター',
    'edit'             => 'プロフィールを編集',
    'edit_user'        => 'ユーザーを編集',
    'password'         => 'パスワード',
    'password_hint'    => '空にすれば現状が維持されます',
    'role'             => 'ロール',
    'roles'            => 'ロール',
    'role_default'     => 'デフォルトロール',
    'roles_additional' => '追加ロール',
    'user_role'        => 'ユーザーロール',
];
