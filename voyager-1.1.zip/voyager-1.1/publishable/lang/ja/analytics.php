<?php

return [
    'by_pageview'            => 'ページビュー毎',
    'by_sessions'            => 'セッション毎',
    'by_users'               => 'ユーザー毎',
    'no_client_id'           => 'アナリティクスを表示するには、GoogleアナリティクスでクライアントIDを取得し、設定の<code>google_analytics_client_id</code>に追加する必要があります。 Googleデベロッパーコンソールでキーを取得:',
    'set_view'               => 'ビューを選択',
    'this_vs_last_week'      => '今週 vs 先週',
    'this_vs_last_year'      => '今年 vs 昨年',
    'top_browsers'           => '上位ブラウザ',
    'top_countries'          => '上位国',
    'various_visualizations' => 'さまざまな視覚化',
];
