<?php

return [
    'by_pageview'  => 'Według odsłon strony',
    'by_sessions'  => 'Według sesji',
    'by_users'     => 'Według użytkowników',
    'no_client_id' => 'Aby wyświetlić statystyki, musisz uzyskać identyfikator klienta Google Analytics i '.
                      'dodać go do ustawień, jako klucz <code>google_analytics_client_id'.
                      '</code>. Zdobądź klucz w konsoli Google Developer:',
    'set_view'               => 'Wybierz widok',
    'this_vs_last_week'      => 'Ten tydzień vs w poprzedni tydzień',
    'this_vs_last_year'      => 'Ten rok vs poprzedni rok',
    'top_browsers'           => 'Top przeglądarki',
    'top_countries'          => 'Top państwa',
    'various_visualizations' => 'Różne wizualizacje',
];
