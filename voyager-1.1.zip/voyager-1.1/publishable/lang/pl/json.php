<?php

return [
    'invalid'           => 'Błędny JSON',
    'invalid_message'   => 'Wygląda na to, że wprowadziłeś nieprawidłowo zbudowany JSON.',
    'valid'             => 'Poprawny JSON',
    'validation_errors' => 'Błędy walidacji',
];
