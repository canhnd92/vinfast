<?php

return [
    'field_password_keep'          => 'Zostaw puste, by zachować hasło bez zmian',
    'field_select_dd_relationship' => 'Upewnij się, by ustawić odpowiednie powiązania w metodzie :method w klasie :class',
    'type_checkbox'                => 'Pole wyboru (checkbox)',
    'type_codeeditor'              => 'Edytor kodu (code editor)',
    'type_file'                    => 'Plik',
    'type_image'                   => 'Obraz',
    'type_radiobutton'             => 'Przycisk wyboru (radio button)',
    'type_richtextbox'             => 'Edytor tekstu (rich textbox)',
    'type_selectdropdown'          => 'Menu wyboru (dropdown)',
    'type_textarea'                => 'Długi tekst (textarea)',
    'type_textbox'                 => 'Pole tekstowe (textbox)',
];
