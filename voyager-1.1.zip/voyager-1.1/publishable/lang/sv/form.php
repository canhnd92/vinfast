<?php

return [
    'field_password_keep'               => 'Lämna tomt för att behålla samma',
    'field_select_dd_relationship'      => 'Kontrollera att du har rätt relation i metoden :method som finns i klassen :class.',
    'type_checkbox'                     => 'Kryssruta',
    'type_codeeditor'                   => 'Kodredigerar',
    'type_file'                         => 'Fil',
    'type_image'                        => 'Bild',
    'type_radiobutton'                  => 'Radioknapp',
    'type_richtextbox'                  => 'Rik textbox',
    'type_selectdropdown'               => 'Rullgardinsmeny',
    'type_textarea'                     => 'Textfält',
    'type_textbox'                      => 'Textbox',
];
