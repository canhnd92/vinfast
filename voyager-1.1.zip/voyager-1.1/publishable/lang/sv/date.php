<?php

return [
    'last_week' => 'Förra Veckan',
    'last_year' => 'Förra Året',
    'this_week' => 'Denna Vecka',
    'this_year' => 'Detta År',
];
