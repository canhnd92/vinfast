<?php

return [
    'page'           => 'Sayfa|Sayfalar',
    'page_link_text' => 'Tüm sayfaları görüntüle',
    'page_text'      => 'Veritabanınızda :count kadar :string bulunuyor. Aşağıdaki butona tıklayarak tüm sayfaları görebilirsiniz.',
    'post'           => 'Gönderi|Gönderiler',
    'post_link_text' => 'Tüm Gönderileri Görüntüle',
    'post_text'      => ':count kadar :string veritabanınızda. Tıklayarak tüm Gönderileri görün.',
    'user'           => 'Kullanıcı|Kullanıcılar',
    'user_link_text' => 'Tüm Kullanıcları Görüntüle',
    'user_text'      => 'Veritabanınızda :count kadar :string bulunuyor. Aşağıdaki butona tıklayarak tüm kullanıcıları görebilirsiniz.',
];
