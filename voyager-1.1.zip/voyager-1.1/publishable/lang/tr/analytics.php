<?php

return [
    'by_pageview'            => 'Sayfa görüntülenmesine göre',
    'by_sessions'            => 'Oturuma göre',
    'by_users'               => 'Kullanıcıya göre',
    'no_client_id'           => 'Analitiği görmek için Google Analytics İstemci Kimliği almanız ve ayarlarınızdaki <code>google_analytics_client_id</code> anahtarına eklemeniz gerekmektedir. Anahtar kodunuzu Google Geliştirici Konsolu\'ndan alın:',
    'set_view'               => 'Bir görünüm seçin',
    'this_vs_last_week'      => 'Bu Hafta ile Geçen Hafta',
    'this_vs_last_year'      => 'Bu Yıl ile Geçen Yıl',
    'top_browsers'           => 'En çok girilen tarayıcı türü',
    'top_countries'          => 'En çok girilen ülke',
    'various_visualizations' => 'Çeşitli görünümler',
];
