<?php

return [
    'last_week' => 'Geçen Hafta',
    'last_year' => 'Geçen Yıl',
    'this_week' => 'Bu Hafta',
    'this_year' => 'Bu Yıl',
];
