<?php

return [
    'symlink_created_text'   => 'Kayıp depolama alanı sembolik bağlantısını sizin için oluşturduk.',
    'symlink_created_title'  => 'Kayıp depolama alanı sembolik bağlantısı oluşturuldu',
    'symlink_failed_text'    => 'Kayıp depolama alanı sembolik bağlantısını sizin için oluştururken hata ile kaşılaşıldı. Servis sağlayıcınız bunu desteklemiyor gibi görünüyor.',
    'symlink_failed_title'   => 'Depolama alanı sembolik bağlantısı oluşturulamadı.',
    'symlink_missing_button' => 'Düzelt',
    'symlink_missing_text'   => 'Depolama alanı sembolik bağlantısı bulamadık. Bu sorun medya dosyalarınızın tarayıcıdan yüklenmesinde sorun çıkartabilir.',
    'symlink_missing_title'  => 'Depolama alanı sembolik bağlantısı eksik',
];
