<?php

return [
    'symlink_created_text'  => 'Kamu telh membuatkan symlink untukmu.',
    'symlink_created_title' => 'Kekurangan storage symlink telah diperbaiki',
    'symlink_failed_text'   => 'Kami gagal membuat storage symlink untuk aplikasi kamu. '.
                                'Sepertinya provider hosting kamu tidak mendukungnya.',
    'symlink_failed_title'   => 'Tidak dapat membuat storage symlink',
    'symlink_missing_button' => 'Perbaiki',
    'symlink_missing_text'   => 'Kami tidak dapat menemukan storage symlink. Ini dapat mengakibatkan masalah '.
                                'ketika melihat file pada browser.',
    'symlink_missing_title' => 'Tidak terdapat storage symlink',
];
