<?php

return [
    'avatar'        => 'Poza',
    'edit'          => 'Editează profilul',
    'edit_user'     => 'Editează utilizatorul',
    'password'      => 'Parola',
    'password_hint' => 'Lăsați gol pentru a păstra aceeași',
    'role'          => 'Rol',
    'user_role'     => 'Rolul utilizatorului',
];
