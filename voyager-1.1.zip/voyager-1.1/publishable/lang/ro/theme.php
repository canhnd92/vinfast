<?php

return [
    'footer_copyright'  => 'Creat cu <i class="voyager-heart"></i> ',
    'footer_copyright2' => 'Creat cu rom și chiar mai mult rom :) ',
];
