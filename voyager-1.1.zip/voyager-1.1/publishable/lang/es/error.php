<?php

return [
    'symlink_created_text'   => 'Acabamos de crear el enlace simbólico que faltaba para usted.',
    'symlink_created_title'  => 'Enlace simbólico de almacenamiento faltante creado',
    'symlink_failed_text'    => 'No hemos podido generar el enlace simbólico perdido para su aplicación. Parece que su proveedor de alojamiento no lo admite.',
    'symlink_failed_title'   => 'No se pudo crear un enlace simbólico de almacenamiento faltante',
    'symlink_missing_button' => 'Arréglalo',
    'symlink_missing_text'   => 'No pudimos encontrar un enlace simbólico de almacenamiento. Esto podría causar problemas con la carga de archivos multimedia desde el navegador.',
    'symlink_missing_title'  => 'Falta el enlace simbólico de almacenamiento',
];
