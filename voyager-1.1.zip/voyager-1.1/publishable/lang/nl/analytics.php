<?php

return [
    'by_pageview'  => 'Per paginaweergave',
    'by_sessions'  => 'Per sessie',
    'by_users'     => 'Per gebruiker',
    'no_client_id' => 'Om analytics in te kunnen zien dient u een Google Analytics client id toe te voegen aan uw instellingen '.
        'onder de naam <code>google_analytics_client_id</code>. De client id kunt u aanvragen in de Google developer console:',
    'set_view'               => 'Selecteer een weergave',
    'this_vs_last_week'      => 'Deze week versus vorige week',
    'this_vs_last_year'      => 'Dit jaar versus vorig jaar',
    'top_browsers'           => 'Top browsers',
    'top_countries'          => 'Top landen',
    'various_visualizations' => 'Verschillende visualisaties',
];
