<?php

return [
    'field_password_keep'          => 'Houd leeg om hetzelfde te behouden',
    'field_select_dd_relationship' => 'Zorg dat u de juiste relatie invoert in de :method methode van '.
        'de :class class.',
    'type_checkbox'       => 'Aankruisvakje',
    'type_codeeditor'     => 'Codebewerker',
    'type_file'           => 'Bestand',
    'type_image'          => 'Afbeelding',
    'type_radiobutton'    => 'Keuzerondje',
    'type_richtextbox'    => 'Rijke tekstvak',
    'type_selectdropdown' => 'Uitschuifkeuzelijst',
    'type_textarea'       => 'Tekstvak',
    'type_textbox'        => 'Tekstveld',
];
