<?php

return [
    'field_password_keep'          => 'Lëreni bosh për të mbajtur të njëjtën',
    'field_select_dd_relationship' => 'Sigurohuni që të konfiguroni marrëdhënien e '
    .'duhur në metodën e metodës së klasa e klasës.',
                                      'the :class class.',
    'type_checkbox'       => 'Kutia e Kontrollit',
    'type_codeeditor'     => 'Editor Kodi',
    'type_file'           => 'Skedar',
    'type_image'          => 'Image',
    'type_radiobutton'    => 'Radio Button',
    'type_richtextbox'    => 'Rich Textbox',
    'type_selectdropdown' => 'Zgjidh Dropdown',
    'type_textarea'       => 'Zona e tekstit',
    'type_textbox'        => 'Kutia e tekstit',
];
