<?php

return [
    'additional_fields'=> 'Campos adicionais',
    'category'         => 'Categoría do Post',
    'content'          => 'Contido do Post',
    'details'          => 'Detalles do Post',
    'excerpt'          => 'Extracto<small> Pequena descripción deste post </small>',
    'image'            => 'Publicar imaxe',
    'meta_description' => 'Meta Descripción',
    'meta_keywords'    => 'Meta palabras clave',
    'new'              => 'Crear novo post',
    'seo_content'      => 'Contido SEO',
    'seo_title'        => 'Título Seo',
    'slug'             => 'URL slug',
    'status'           => 'Estado do Post',
    'status_draft'     => 'borrador',
    'status_pending'   => 'pendente',
    'status_published' => 'publicado',
    'title'            => 'Título do Post',
    'title_sub'        => 'O título de Post',
    'update'           => 'Actualizar Post',
];
