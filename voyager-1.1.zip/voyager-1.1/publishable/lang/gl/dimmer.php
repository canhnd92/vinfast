<?php

return [
    'page'           => 'Páxina|Páxinas',
    'page_link_text' => 'Ver tódalas páxinas',
    'page_text'      => 'Ten :count :string na súa base de datos. Faga clic no botón de abaixo para ver tódalas páxinas. ',
    'post'           => 'Post|Posts',
    'post_link_text' => 'Ver tódolos posts',
    'post_text'      => 'Ten :count :string na súa base de datos. Faga clic no botón de abaixo para ver tódolos posts. ',
    'user'           => 'Usuario|Usuarios',
    'user_link_text' => 'Ver tódolos usuarios',
    'user_text'      => 'Ten :count :string na súa base de datos. Faga clic no botón de abaixo para ver tódolos usuarios. ',
];
