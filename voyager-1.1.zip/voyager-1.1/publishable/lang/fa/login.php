<?php

return [
    'loggingin'    => 'ورود',
    'signin_below' => 'در زیر وارد شوید:',
    'welcome'      => 'به Voyager پنل ادمینی که لاراول کم داشت خوش آمدید!',
];
